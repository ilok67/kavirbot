// GM_getValue / GM_setValue on top of the native encrypted store.
if (typeof KTNative === 'undefined') return;
window.GM_getValue = function (k, d) {
    try {
        var raw = KTNative.get(String(k));
        if (raw === null || raw === undefined) return d;
        return JSON.parse(raw);
    } catch (e) { return d; }
};
window.GM_setValue = function (k, v) {
    try { KTNative.set(String(k), JSON.stringify(v === undefined ? null : v)); } catch (e) {}
};

// ---- KavirBot: return to the products page when the site bounces us to /esale ----
// The userscript stops its engine when the path is not /esale/products. If the site redirects
// to /esale while the bot is ON (and no payment flow has started), go back after a polite delay.
(function () {
    if (location.hostname !== 'kavirtire.ir') return;
    var RETURN_DELAY = 4000, MAX_RETURNS = 200;
    try {
        var p = location.pathname.replace(/\/+$/, '');
        if (p.indexOf('/esale/payment') === 0) sessionStorage.setItem('kb_paid', '1');
        if (p !== '/esale') return;
        if (localStorage.getItem('KT11_BOT_ENABLED') !== '1') return;
        if (sessionStorage.getItem('kb_paid') === '1') return;
        var n = Number(sessionStorage.getItem('kb_returns') || 0);
        if (n >= MAX_RETURNS) return;
        setTimeout(function () {
            try {
                if (localStorage.getItem('KT11_BOT_ENABLED') !== '1') return;
                sessionStorage.setItem('kb_returns', String(n + 1));
                location.href = '/esale/products';
            } catch (e) {}
        }, RETURN_DELAY);
    } catch (e) {}
})();

// ---- KavirBot: mobile layout fallback for the "refresh availability" button ----
// The userscript looks for '[data-refresh-availability], .refresh-availability'. On the mobile
// layout that element may be missing or hidden, and the visible button is the bottom-bar
// "بروزرسانی". Return that one instead (only for this exact selector).
(function () {
    var SEL = '[data-refresh-availability], .refresh-availability';
    var orig = Document.prototype.querySelector;
    function shown(el) { return !!el && el.getClientRects().length > 0; }
    Document.prototype.querySelector = function (sel) {
        var r = orig.apply(this, arguments);
        if (sel !== SEL || shown(r)) return r;
        try {
            var cands = orig.call(this, 'body') ? this.querySelectorAll('button, a, [role="button"]') : [];
            for (var i = 0; i < cands.length; i++) {
                var el = cands[i];
                if (el.closest && el.closest('[id^="kt11"]')) continue;
                if (!shown(el) || el.disabled) continue;
                var t = (el.textContent || '').replace(/\s+/g, ' ').trim();
                if (t.indexOf('بروزرسانی') === 0 && t.length <= 30) return el;
            }
        } catch (e) {}
        return r;
    };
})();
